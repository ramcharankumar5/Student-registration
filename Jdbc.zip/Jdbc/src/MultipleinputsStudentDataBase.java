import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import oracle.jdbc.driver.OracleDriver;

public class MultipleinputsStudentDataBase {

	public static void main(String[] args) throws ClassNotFoundException {
		int sum=0;
		 String DB_URL = "jdbc:oracle:thin:@//localhost:1521/XE";

		    String USER = "SYSTEM";
		    String PASS = "SYSTEM";
		 Connection conn = null;
		   Statement stmt = null;
		   ResultSet rs=null;
		   PreparedStatement pstmt=null;
		   Scanner sc=null;
		   sc=new Scanner(System.in);
		   int n=0;
		   if(sc!=null)
		   {
			   System.out.println("enter the number of the students");
			   n=sc.nextInt();
		   }
		   try
		   {
				DriverManager.registerDriver(new OracleDriver());
			      conn = DriverManager.getConnection(DB_URL, USER, PASS);
			      String str = "insert into studentdetails values(?,?,?,?,?)";
if(conn!=null)
{
	pstmt=conn.prepareStatement(str);

}
if(sc!=null && pstmt!=null)
{
	for(int i=0;i<=n;i++)
	{
		System.out.println("enter the student details"+i);
		System.out.println("enter the SIDNO ");
		int a=sc.nextInt();
		System.out.println("enter the SNAME ");
		String b=sc.next();
		System.out.println("enter the adress ");
		String c=sc.next();
		System.out.println("enter the telugu ");
		int d=sc.nextInt();
		System.out.println("enter the maths ");
		int e=sc.nextInt();
		pstmt.setInt(1, a);
		pstmt.setString(2, b);
		pstmt.setString(3, c);
		pstmt.setInt(4, d);
		pstmt.setInt(5, e);
	int	res=pstmt.executeUpdate();
	
	if(res==0)
	{
		System.out.println(i+"student details are not inserted");
	}
	else
	{
		System.out.println(i+"student details are inserted");

	}
	 
		
	}
}

		   }
		   catch(SQLException se)
		   {
		      //Handle errors for Class.forName
		      se.printStackTrace();
		   }
		   catch(Exception se)
		   {
		      //Handle errors for Class.forName
		      se.printStackTrace();
		   }
		   finally{
			      //finally block used to close resources
			      try{
			         if(stmt!=null)
			            conn.close();
			      }catch(SQLException se){
			      }// do 
			      try{
			         if(conn!=null)
			            conn.close();
			      }catch(SQLException se){
			         se.printStackTrace();
			      }//end finally try
			   }//end try
			   System.out.println("Goodbye!");
		   }
	}


