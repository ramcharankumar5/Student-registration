import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.driver.OracleDriver;

public class Insert  {

	static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/XE";

	   static final String USER = "SYSTEM";
	   static final String PASS = "SYSTEM";
	   
	   public static void main(String[] args) throws Exception{
	   Connection conn = null;
	   Statement stmt = null;
	   ResultSet rs=null;
	   try{
	      //STEP 2: Register JDBC driver
			DriverManager.registerDriver(new OracleDriver());

	      //STEP 3: Open a connection
	      System.out.println("Connecting to a selected database...");
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	      System.out.println("Connected database successfully...");
	      
	      //STEP 4: Execute a query
	      System.out.println("Inserting records into the table...");
	      stmt = conn.createStatement();
	      
	      String sql = "INSERT INTO emp " +
	                   "VALUES (100, 'Zara', 18)";
	      String sql1 = "INSERT INTO emp " +
                  "VALUES (120, 'PAWAN', 19)";
	      String sql2 = "INSERT INTO emp " +
                  "VALUES (130, 'charan', 20)";
	      String sql3 = "INSERT INTO emp " +
                  "VALUES (140, 'ggg', 21)";
	      stmt.executeUpdate(sql+"\n");
	      stmt.executeUpdate(sql1+"\n");
	      stmt.executeUpdate(sql2);
	      stmt.executeUpdate(sql3);


	      System.out.println("Inserted records into the table...");
	      System.out.println("Fetching records with condition...");
	      sql = "SELECT usn, name, marks1 FROM emp" +
	                   " WHERE usn >= 100 ";
	      rs = stmt.executeQuery(sql);
	      String newLine = System.getProperty("line.separator");
	      while(rs.next()){
	         //Retrieve by column name
	    	  int usn = rs.getInt("usn");
		         String name = rs.getString("name");
		         int marks1 = rs.getInt("marks1");

	         //Display values
		         System.out.print("ID: " + usn);
		         System.out.print(", Age: " + name);
		         System.out.print(", First: " + marks1);
		     
	      }
	      rs.close();
	   }catch(SQLException se)
	   {
	      //Handle errors for Class.forName
	      se.printStackTrace();
	   }finally{
	      //finally block used to close resources
	      try{
	         if(stmt!=null)
	            conn.close();
	      }catch(SQLException se){
	      }// do nothing
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }//end finally try
	   }//end try
	   System.out.println("Goodbye!");

	}

}
