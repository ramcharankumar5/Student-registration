

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import oracle.jdbc.driver.OracleDriver;

public class studentdatabase4{

	static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/XE";

	   static final String USER = "SYSTEM";
	   static final String PASS = "SYSTEM";
	   
	   public static void main(String[] args) throws Exception,NullPointerException{
	   Connection conn = null;
	   Statement stmt = null;
	   ResultSet rs=null;
	   PreparedStatement pstmt=null;
	   try{
	      //STEP 2: Register JDBC driver
			DriverManager.registerDriver(new OracleDriver());

	      //STEP 3: Open a connection
	      System.out.println("Connecting to a selected database...");
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	      System.out.println("Connected database successfully...");
	      
	      //STEP 4: Execute a query
	      System.out.println("Inserting records into the table...");
	      
	     
	      String str = "insert into studentdetails values(?,?,?,?,?,?,?,?,?,?,?)";
			
			pstmt=conn.prepareStatement(str);
			
			Scanner scan=new Scanner(System.in);
			System.out.println("enter the SIDNO ");
			int a=scan.nextInt();
			System.out.println("enter the SNAME ");
			String b=scan.next();
			System.out.println("enter the adress ");
			String c=scan.next();
			System.out.println("enter the TELUGU ");
			int d=scan.nextInt();
			System.out.println("enter the HINDI ");
			int e=scan.nextInt();
			System.out.println("enter the ENGLISH ");
			int f=scan.nextInt();
			System.out.println("enter the MATHEMATICS ");
			int g=scan.nextInt();
			System.out.println("enter the SCIENCE ");
			int h=scan.nextInt();
			System.out.println("enter the SOCIAL ");
			int i=scan.nextInt();
			System.out.println("enter the total marks ");
			int j=scan.nextInt();
			pstmt.setInt(1, a);
			pstmt.setString(2, b);
			pstmt.setString(3, c);
			pstmt.setInt(4, d);pstmt.setInt(5, e);pstmt.setInt(6, f);pstmt.setInt(7, g);pstmt.setInt(8, h);pstmt.setInt(9, i);
	        pstmt.executeUpdate();
	        
	      while(rs.next()){
	         //Retrieve by column name
	    	  int usn = rs.getInt("sidno");
		         String name = rs.getString("sname");
		         String adress= rs.getString("sadress");
		         int telugu= rs.getInt("telugu");
		         int hindi= rs.getInt("hindi");
		         int english= rs.getInt("english");
		         int maths= rs.getInt("maths");
		         int science= rs.getInt("science");
		         int social= rs.getInt("social");
		         int totalmarks= rs.getInt("totalmarks");


	         //Display valuesl
		         System.out.print("ID: " + usn);
		         System.out.print(", Age: " + name);
		         System.out.print("adress"+ adress);
		         System.out.print(", telugu: " + telugu);
		         System.out.print(", hindi: " + hindi);
		         System.out.print(", english: " + english);
		         System.out.print(", maths: " + maths);
		         System.out.print(", science: " + science);
		         System.out.print(", social: " + social);
		         System.out.print(", social: " + totalmarks);

		     
	      }
	      System.out.println("Fetching records without condition...");
	      

	   }
	   
     catch(SQLException se)
	   {
	      //Handle errors for Class.forName
	      se.printStackTrace();
	   }finally{
	      //finally block used to close resources
	      try{
	         if(stmt!=null)
	            conn.close();
	      }catch(SQLException se){
	      }// do 
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }//end finally try
	   }//end try
	   System.out.println("Goodbye!");

	}

}
