


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import oracle.jdbc.driver.OracleDriver;

public class Studentdatabase3 {

	static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/XE";

	   static final String USER = "SYSTEM";
	   static final String PASS = "SYSTEM";
	   
	   public static void main(String[] args) throws Exception,NullPointerException{
	   Connection conn = null;
	   Statement stmt = null;
	   ResultSet rs=null;
	   PreparedStatement pstmt=null;
	   try{
	      //STEP 2: Register JDBC driver
			DriverManager.registerDriver(new OracleDriver());

	      //STEP 3: Open a connection
	      System.out.println("Connecting to a selected database...");
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	      System.out.println("Connected database successfully...");
	      
	      //STEP 4: Execute a query
	      System.out.println("Inserting records into the table...");
	      
	     
	      String str = "insert into studentdatabase values(?,?,?,?)";
			
			pstmt=conn.prepareStatement(str);
			
			Scanner scan=new Scanner(System.in);
			System.out.println("enter the SIDNO ");
			int a=scan.nextInt();
			System.out.println("enter the SNAME ");
			String b=scan.next();
			System.out.println("enter the adress ");
			String c=scan.next();
			System.out.println("enter the SMARKS ");
			int d=scan.nextInt();
			pstmt.setInt(1, a);pstmt.setString(2, b);pstmt.setString(3, c);pstmt.setInt(4, d);pstmt.executeUpdate();
			System.out.println("query executed");

	      while(rs.next()){
	         //Retrieve by column name
	    	  int usn = rs.getInt("sidno");
		         String name = rs.getString("sname");
		         String adress= rs.getString("sadress");
		         int marks1 = rs.getInt("smarks");
	         //Display valuesl
		         System.out.print("ID: " + usn);
		         System.out.print(", Age: " + name);
		         System.out.println("adress"+ adress);
		         System.out.print(", First: " + marks1);
	      }
	      System.out.println("to check the if else condition");
	   }
	   
     catch(SQLException se)
	   {
	      //Handle errors for Class.forName
	      se.printStackTrace();
	   }finally{
	      //finally block used to close resources
	      try{
	         if(stmt!=null)
	            conn.close();
	      }catch(SQLException se){
	      }// do 
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }//end finally try
	   }//end try
	   System.out.println("Goodbye!");

	}

}


