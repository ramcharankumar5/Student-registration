import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import oracle.jdbc.driver.OracleDriver;

public class Ifelsecondition {

	static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/XE";

	   static final String USER = "SYSTEM";
	   static final String PASS = "SYSTEM";
	   
	   public static void main(String[] args) throws Exception{
	   Connection conn = null;
	   Statement stmt = null;
	   ResultSet rs=null;
	   PreparedStatement pstmt=null;
	   try{
	      //STEP 2: Register JDBC driver
			DriverManager.registerDriver(new OracleDriver());

	      //STEP 3: Open a connection
	      System.out.println("Connecting to a selected database...");
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	      System.out.println("Connected database successfully...");
	      
	      //STEP 4: Execute a query
	      System.out.println("Inserting records into the table...");
	      stmt = conn.createStatement();
	      
	      String sql = "INSERT INTO emp " +
	                   "VALUES (100, 'Zara', 18)";
	      String sql1 = "INSERT INTO emp " +
               "VALUES (120, 'PAWAN', 19)";
	      String sql2 = "INSERT INTO emp " +
               "VALUES (130, 'charan', 20)";
	      String sql3 = "INSERT INTO emp " +
               "VALUES (140, 'ggg', 21)";
	      stmt.executeUpdate(sql);
	      stmt.executeUpdate(sql1);
	      stmt.executeUpdate(sql2);
	      stmt.executeUpdate(sql3);
	      String str = "insert into emp values(?,?,?)";
			
			pstmt=conn.prepareStatement(str);
			Scanner scan=new Scanner(System.in);
			System.out.println("enter the SIDNO ");
			int a=scan.nextInt();
			System.out.println("enter the SNAME ");
			String b=scan.next();
			System.out.println("enter the SMARKS ");
			int d=scan.nextInt();
			
			pstmt.setInt(1, a);
			pstmt.setString(2, b);
			pstmt.setInt(3, d);
			pstmt.executeUpdate();
			System.out.println("query executed");


	      System.out.println("Fetching records with condition...");
	      sql = "SELECT usn, name, marks1 FROM emp" +
	                   " WHERE usn >= 100 ";
	      rs = stmt.executeQuery(sql);

	      while(rs.next()){
	         //Retrieve by column name
	    	  int usn = rs.getInt("usn");
		         String name = rs.getString("name");
		         int marks1 = rs.getInt("marks1");
	         //Display valuesl
		         System.out.print("ID: " + usn);
		         System.out.print(", Age: " + name);
		         System.out.print(", First: " + marks1);
		     
	      }
	      System.out.println("to check the if else condition");
sql="SELECT usn,name,marks1, CASE WHEN marks1>40 THEN 'A grade' WHEN marks1 < 40 AND marks1 >30  THEN 'B grade' WHEN marks1 BETWEEN 10 AND 29 THEN 'c grade' ELSE 'fail' END FROM   emp";
     rs = stmt.executeQuery(sql);
     while(rs.next()){
         //Retrieve by column name
	         int marks1 = rs.getInt("marks1");
	         System.out.println(", First: " + rs);

     }
	   }catch(SQLException se)
	   {
	      //Handle errors for Class.forName
	      se.printStackTrace();
	   }finally{
	      //finally block used to close resources
	      try{
	         if(stmt!=null)
	            conn.close();
	      }catch(SQLException se){
	      }// do 
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }//end finally try
	   }//end try
	   System.out.println("Goodbye!");

	}

}
