package project1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import oracle.jdbc.driver.OracleDriver;

public class RetrivethedaTA {
	static int sum=0;
	static int sum1=0;

	static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/XE";

	   static final String USER = "SYSTEM";
	   static final String PASS = "SYSTEM";
	   
	   public static void main(String[] args) {
	   Connection conn = null;
	   Statement stmt = null;
	   try{
	      //STEP 2: Register JDBC driver
			DriverManager.registerDriver(new OracleDriver());

	      //STEP 3: Open a connection
	      System.out.println("Connecting to a selected database...");
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	      System.out.println("Connected database successfully...");
	      
	      //STEP 4: Execute a query
	      System.out.println("Creating statement...");
	      stmt = conn.createStatement();

	      // Extract records without any condition.
	      System.out.println("==========================================================================");

			System.out.println("Fetching records without condition...");
		      String sql = "SELECT sidno, sname, sadress, telugu, english FROM studentdetails";
		      ResultSet rs = stmt.executeQuery(sql);
	      while(rs.next()){
	    	  Scanner scan=new Scanner(System.in);
	    	  
	         //Retrieve by column name
	    	  int a=rs.getInt("sidno");
				String b=rs.getString("sname");
				String c=rs.getString("sadress");
				System.out.println("enter the student marks");
				int d=rs.getInt("telugu");
				int e=rs.getInt("english");
			System.out.println("SN:"+" "+a+" "+"NAME :"+" "+b+" "+"ADRESS:"+" "+c+" "+"telugu:"+" "+d+" "+"english:"+" "+e);
	      }
	      System.out.println("==========================================================================");
System.out.println("STUDENTS total TELUGU MARKS");
	      ResultSet res = stmt.executeQuery("SELECT SUM(telugu)  FROM studentdetails");
	      while (res.next()) {
	        int c11 = res.getInt(1);
	        sum = sum + c11;
	      }
	      System.out.println("Sum of telugu marks = " + sum);
	      System.out.println("==========================================================================");
	      System.out.println("STUDENTS AVERAGE MARKS");

	      
	      ResultSet res1 = stmt.executeQuery("SELECT AVG(telugu) FROM studentdetails");
	      while (res1.next()) 
	    	  System.out.println("avg temp is " + res1.getFloat(1));
	      System.out.println("===========================================================================");
	      System.out.println("to check the GRADING");
	      String grading = "SELECT sidno, sname, sadress, telugu, english FROM studentdetails";
	        ResultSet res2 = stmt.executeQuery(grading);
	        
	        while (res2.next())
	        {
	        	int a=res2.getInt("sidno");
				String b=res2.getString("sname");
				String c=res2.getString("sadress");
				int d=res2.getInt("telugu");
				int e=res2.getInt("english");
			System.out.println("Student id:"+" "+a+" "+"NAME :"+" "+b+" "+"ADRESS:"+" "+c+" "+"telugu:"+" "+d+" "+"english:"+" "+e);
	            if (d<80)
	            {
	                System.out.println("A GRADE");
	            } else if (d<95)
	            {
	                System.out.println("B GRADE");
	            } 
	            else if (d==95)
	            {
	                System.out.println("a+ GRADE");
	            } 
	            else if (d<40)
	            {
	                System.out.println("JUST PASS");
	            } 
	        }	      System.out.println("===========================================================================");

	      // Select all records having ID equal or greater than 101
	     
	   }catch(SQLException se){
	      //Handle errors for JDBC
	      se.printStackTrace();
	   }catch(Exception e){
	      //Handle errors for Class.forName
	      e.printStackTrace();
	   }finally{
	      //finally block used to close resources
	      try{
	         if(stmt!=null)
	            conn.close();
	      }catch(SQLException se){
	      }// do nothing
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }//end finally try
	   }//end try
	   System.out.println("Goodbye!");
	}

}
