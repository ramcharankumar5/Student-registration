
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import oracle.jdbc.driver.OracleDriver;

public class Studentdatabase {

	public static void main(String[] args) {
		String url="jdbc:oracle:thin:@//localhost:1521/XE";
		String un="SYSTEM";
		String pwd="SYSTEM";
		Connection con=null;
			Statement stmt=null;
		ResultSet rs=null;
		PreparedStatement pstmt=null;
		
		
try {
	DriverManager.registerDriver(new OracleDriver());
	System.out.println("driver loaded succesfully");
} catch (SQLException e) {
	System.out.println("driver loaded established succesfully");
}
	try {
		 con=DriverManager.getConnection(url,un,pwd);
		System.out.println("connection loaded succesfully");
	} catch (SQLException e) {
		System.out.println("connection canot loaded sucessfully");
	}
	try
	{
	String s="select*from emp Where usn=?";
	pstmt=con.prepareStatement(s);
	Scanner scan=new Scanner(System.in);
	System.out.println("enter the usn");
	String temp=scan.next(s);
	pstmt.setString(1, temp);
	rs=pstmt.executeQuery();
	System.out.println("query executed succesfully");
	}
	catch(SQLException e)
	{
		System.out.println("query not executed ");
	}
try
{
	while(rs.next()==true)
	{
		int a=rs.getInt("usn");
		String b=rs.getString("name");
		String c=rs.getString("address");
		int d=rs.getInt("marks1");
		int e=rs.getInt("marks2");
		float f=rs.getFloat("average");
	System.out.println("USN"+" "+a+" "+"NAME"+" "+b+" "+"ADRESS:"+" "+c+" "+"MARKS1"+" "+d+" "+"MARKS2"+" "+e+" "+"AVERAGE"+" "+f);
}
}
catch(SQLException e)
{
	System.out.println("enable to print the data");
}
	}
	}


